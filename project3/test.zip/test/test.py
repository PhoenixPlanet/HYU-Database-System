import random

f = open("./test/test.txt", 'w')
f.write("z 100000\n")
for i in range(1, 11):
    f.write("o ./t" + str(i) + ".db\n")
test_list_insert = list(range(1, 5000))
test_list_insert2 = list(range(200, 301))
test_list_delete = list(range(1, 99900))
test_list_find = list(range(1, 100001))
#random.shuffle(test_list_insert)
#random.shuffle(test_list_delete)
#test_list_insert.reverse()
test_list_delete.reverse()
test_list_find.reverse()

test_file_list = list(range(1, 11))
random.shuffle(test_file_list)

for j in test_file_list:
    #random.shuffle(test_list_insert)
    #random.shuffle(test_list_delete)
    for i in test_list_insert:
        f.write("i " + str(j) + " " + str(i) + " test wow perfect asdf " + str(i) + "\n")
    """for i in test_list_delete:
        f.write("d " + str(j) + " " + str(i) + "\n")
    for i in test_list_find:
        f.write("f " + str(j) + " " + str(i) + "\n")
    for i in test_list_insert2:
        f.write("i " + str(j) + " " + str(i) + " test wow perfect asdf " + str(i) + "\n")"""

for j in test_file_list:
    f.write("p " + str(j) + "\n")
f.write("s")

f.close()
