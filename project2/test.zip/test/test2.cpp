#include "bptapi.h"

#include <fstream>

// MAIN

int main( int argc, char ** argv ) {

    char * input_file;
    FILE * fp;
    int64_t input, range2;
    char instruction;
    char value[120];
    int a;

    if (argc > 1) {
        input_file = argv[1];
        fp = fopen(input_file, "r");
        if (fp == NULL) {
            perror("Failure  open input file.");
            exit(EXIT_FAILURE);
        }
        while (!feof(fp)) {
            fscanf(fp, "%d\n", &input);
            //root = insert_key(root, input, input);
        }
        fclose(fp);
        //print_tree(root);
    }

    printf("> ");
    while (scanf("%c", &instruction) != EOF) {
        switch (instruction) {
        case 'd':
            scanf("%ld", &input);
            if (db_delete(input) == 0) {
                printf("delete success\n");
            } else {
                printf("delete failed\n");
            }
            //print_tree(root);
            break;
        case 'i':
            scanf("%ld", &input);
            scanf("%s", value);
            printf("insert: %ld, %s\n", input, value);
            if (db_insert(input, value) == 0) {
                printf("insert success: %ld, %s\n", input, value);
            } else {
                printf("insert failed\n");
            }
            //root = insert_key(root, input, input);
            //print_tree(root);
            break;
        case 'f':
            scanf("%d", &input);
            if (db_find(input, value) == 0) {
                printf("find success: %ld, %s\n", input, value);
            } else {
                printf("find failed\n");
            }
            //root = insert_key(root, input, input);
            //print_tree(root);
            break;
        case 'p':
            db_print_tree();
            break;
        case 'l':
            db_print_leaf();
            break;
        case 'o':
            scanf("%s", value);
            a = open_table(value);
            printf("open: %d\n", a);
            //print_leaves(root);
            break;
        default:
            break;
        }
        while (getchar() != (int)'\n');
        printf("> ");
    }
    printf("\n");

    return EXIT_SUCCESS;
}
