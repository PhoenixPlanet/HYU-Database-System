import random

f = open("./test/test.txt", 'w')
f.write("o t.db\n")
test_list_insert = list(range(1, 4001))
#test_list_delete = list(range(200, 999901))
#test_list_find = list(range(1, 1000001))
random.shuffle(test_list_insert)
#random.shuffle(test_list_delete)
#test_list_delete.reverse()
for i in test_list_insert:
    f.write("i " + str(i) + " test wow perfect asdf " + str(i) + "\n")
    #f.write("f " + str(i) + "\n")
    #f.write("d " + str(i) + "\n")
#for i in test_list_delete:
    #f.write("i " + str(i) + " test wow perfect asdf " + str(i) + "\n")
    #f.write("f " + str(i) + "\n")
    #f.write("d " + str(i) + "\n")
#for i in test_list_find:
    #f.write("i " + str(i) + " test wow perfect asdf " + str(i) + "\n")
    #f.write("f " + str(i) + "\n")
    #f.write("d " + str(i) + "\n")
f.write("p")

f.close()